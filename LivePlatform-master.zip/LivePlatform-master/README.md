# mysite
一个教育直播平台，支持视频直播、白板演示、代码编辑、PPT播放、聊天等功能

前端文档见Group3\frontend\out\index.html

后端文档见Group3\doc\_build\html\index.html

部署文档见wiki中Deploy页

功能性测试文档见wiki中Fuction_test02(最终版)